$(document).ready(function () {
    $.ajax({
        url: "https://traveller.talrop.works/api/v1/places/categories/",
        type: "GET",
        success: function (data) {
            console.log("Categories Data: ", data);
            // Perform operations with the data received
        },
        error: function (error) {
            console.error("Error fetching categories data: ", error);
        },
    });

    $.ajax({
        url: "https://traveller.talrop.works/api/v1/places/",
        type: "GET",
        success: function (data) {
            console.log("Places Data: ", data);
            // Perform operations with the data received
        },
        error: function (error) {
            console.error("Error fetching places data: ", error);
        },
    });
});