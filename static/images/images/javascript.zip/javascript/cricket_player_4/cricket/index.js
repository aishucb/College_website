let sachin = require("./data/sachin.json");
let sehwag = require("./data/sehwag.json");
let yuvraj = require("./data/yuvraj.json");
let dravid = require("./data/dravid.json");
let ganguly = require("./data/ganguly.json");
let virat = require("./data/virat.json"); 


function findPlayerWithMostFours(...players) {
    let maxFours = 0;
    let playerWithMostFours = null;

    for (const player of players) {
        const battingData = player.data.batting;

       
        const t20Fours = (battingData.T20Is && battingData.T20Is["4s"]) ? parseInt(battingData.T20Is["4s"]) : 0;

        const fours =
            parseInt(battingData.tests["4s"]) +
            parseInt(battingData.ODIs["4s"]) +
            t20Fours +
            parseInt(battingData.firstClass["4s"]) +
            parseInt(battingData.listA["4s"]);

        if (fours > maxFours) {
            maxFours = fours;
            playerWithMostFours = player;
        }
    }

    return playerWithMostFours;
}


function findPlayerWithMostSixes(...players) {
    let maxSixes = 0;
    let playerWithMostSixes = null;

    for (const player of players) {
        const battingData = player.data.batting;

        
        const t20Sixes = (battingData.T20Is && battingData.T20Is["6s"]) ? parseInt(battingData.T20Is["6s"]) : 0;

        const sixes =
            parseInt(battingData.tests["6s"]) +
            parseInt(battingData.ODIs["6s"]) +
            t20Sixes +
            parseInt(battingData.firstClass["6s"]) +
            parseInt(battingData.listA["6s"]);

        if (sixes > maxSixes) {
            maxSixes = sixes;
            playerWithMostSixes = player;
        }
    }

    return playerWithMostSixes;
}


function findPlayerWithMostRuns(...players) {
    let maxRuns = 0;
    let playerWithMostRuns = null;

    for (const player of players) {
        const battingData = player.data.batting;

        
        const t20Runs = (battingData.T20Is && battingData.T20Is["Runs"]) ? parseInt(battingData.T20Is["Runs"]) : 0;

        const runs =
            parseInt(battingData.tests.Runs) +
            parseInt(battingData.ODIs.Runs) +
            t20Runs +
            parseInt(battingData.firstClass.Runs) +
            parseInt(battingData.listA.Runs);

        if (runs > maxRuns) {
            maxRuns = runs;
            playerWithMostRuns = player;
        }
    }

    return playerWithMostRuns;
}


function findPlayerWithMostWickets(...players) {
    let maxWickets = 0;
    let playerWithMostWickets = null;

    for (const player of players) {
        const bowlingData = player.data.bowling;

        
        const t20Wickets = (bowlingData.T20Is && bowlingData.T20Is["Wkts"]) ? parseInt(bowlingData.T20Is["Wkts"]) : 0;

        const wickets =
            parseInt(bowlingData.tests.Wkts) +
            parseInt(bowlingData.ODIs.Wkts) +
            t20Wickets +
            parseInt(bowlingData.firstClass.Wkts) +
            parseInt(bowlingData.listA.Wkts);

        if (wickets > maxWickets) {
            maxWickets = wickets;
            playerWithMostWickets = player;
        }
    }

    return playerWithMostWickets;
}


const mostFoursPlayer = findPlayerWithMostFours(sachin, sehwag, yuvraj, dravid, ganguly, virat);
const mostSixesPlayer = findPlayerWithMostSixes(sachin, sehwag, yuvraj, dravid, ganguly, virat);
const mostRunsPlayer = findPlayerWithMostRuns(sachin, sehwag, yuvraj, dravid, ganguly, virat);
const mostWicketsPlayer = findPlayerWithMostWickets(sachin, sehwag, yuvraj, dravid, ganguly, virat);

console.log("Player with the most fours in batting:", mostFoursPlayer ? mostFoursPlayer.fullName : "N/A");
console.log("Player with the most sixes in batting:", mostSixesPlayer ? mostSixesPlayer.fullName : "N/A");
console.log("Player with the most runs in batting:", mostRunsPlayer ? mostRunsPlayer.fullName : "N/A");
console.log("Player with the most wickets in bowling:", mostWicketsPlayer ? mostWicketsPlayer.fullName : "N/A");
