function scoreCalculator(wins, draws, losses) {
    var totalPoints = (wins * 3) + (draws * 1) + (losses * 0);
    return totalPoints;
  }
  
  var totalScore = scoreCalculator(5, 0, 2);
  console.log("Total score: " + totalScore);
  