function findLargestInteger() {
    const input1 = document.getElementById("input1").value;
    const input2 = document.getElementById("input2").value;
  
    
    const num1 = parseInt(input1);
    const num2 = parseInt(input2);
  
    
    if (isNaN(num1) || isNaN(num2)) {
      document.getElementById("result").innerHTML = "Error: Please enter two valid integers.";
    } else {
      
      const largest = num1 > num2 ? num1 : num2;
      document.getElementById("result").innerHTML = "The largest integer is: " + largest;
    }
  }
  