const students = [
    {
      name: "Student 1",
      class: "A",
      division: "I",
      marks: [85, 90, 78, 92],
    },
    {
      name: "Student 2",
      class: "A",
      division: "II",
      marks: [78, 88, 92, 87],
    },
    {
      name: "Student 3",
      class: "B",
      division: "I",
      marks: [90, 88, 75, 94],
    },
  ];
  
  function calculateTotalMarks(student) {
    return student.marks.reduce((total, mark) => total + mark, 0);
  }
  
  let highestTotalMarks = 0;
  let topper = 0;
  
  for (const student of students) {
    const totalMarks = calculateTotalMarks(student);
    if (totalMarks > highestTotalMarks) {
      highestTotalMarks = totalMarks;
      topper = student;
    }
  }
  
  if (topper !== 0) {
    console.log(`The topper is ${topper.name} with ${highestTotalMarks} marks.`);
  } else {
    console.log("No student data found.");
  }
  