const store1Products = [
    { name: "apple",
      quantity: 500, 
      price: 100
    },
    { name: "orange",
      quantity: 300,
      price: 150 
    },
    { name: "mango",
      quantity: 200, 
      price: 200 
    },
  ];
  
  const store2Products = [
    { name: "apple", 
      quantity: 400, 
      price: 120 
    },
    { name: "orange",
      quantity: 600, 
      price: 180 
    },
    { name: "mango", 
      quantity: 600,
      price: 250 
    },
  ];
  
  const store3Products = [
    { name: "apple",
      quantity: 200,
      price: 80
    },
    { name: "orange",
      quantity: 800,
      price: 140 
    },
    { name: "mango",
      quantity: 400,
      price: 220
    },
  ];
  
  // Initialize total cost variables for each store
  let store1_total = 0;
  let store2_total = 0;
  let store3_total = 0;
  
  // Calculate total cost for each store
  function calculateStoreTotal(storeProducts) {
    return storeProducts.reduce((total, product) => total + product.quantity * product.price, 0);
  }
  
  store1_total = calculateStoreTotal(store1Products);
  store2_total = calculateStoreTotal(store2Products);
  store3_total = calculateStoreTotal(store3Products);
  
  // Create an object to store total costs for each store
  const totalCost = {
    store1: store1_total,
    store2: store2_total,
    store3: store3_total,
  };
  
  console.log("Total Cost for Each Store:");
  console.log(totalCost);
  