function arrayFunctions() {
    
    const array1 = [1, 2, 3];
    const array2 = [4, 5, 6];
  
    const concatenatedArray = array1.concat(array2);
  
    const reversedArray = concatenatedArray.reverse();
  
    console.log(reversedArray);
  }
  
  arrayFunctions();
  